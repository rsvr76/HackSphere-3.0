/**
 * Official HackSphere 3.0 Microgrid Transition & Alert Evaluator
 *
 * Rules:
 * 1. Demand > 160 kW OR Hour in [18, 19, 20, 21, 22] -> Renewable Storage Mode
 * 2. Otherwise -> Main Grid Mode
 * 3. Demand >= 200 kW -> Critical Overload Alert (independent of mode)
 */

export type GridMode = "RENEWABLE_STORAGE" | "MAIN_GRID";
export type StatusColor = "rose" | "emerald" | "sky";

export interface TelemetryPoint {
  timestamp: string; // ISO string
  ambient_temp_c: number;
  humidity_pct: number;
  solar_irradiance_wm2: number;
}

export interface ForecastPoint extends TelemetryPoint {
  hour: number;
  hourLabel: string;
  demandKw: number;
  mode: GridMode;
  reason: string;
  isOverload: boolean;
  isPeakHour: boolean;
  isHighDemand: boolean;
  statusColor: StatusColor;
  batterySoc: number;
  batteryFlowKw: number; // positive = charging, negative = discharging
}

export interface GridEvaluation {
  hour: number;
  demandKw: number;
  mode: GridMode;
  isOverload: boolean;
  reason: string;
  isPeakHour: boolean;
  isHighDemand: boolean;
  statusColor: StatusColor;
}

export function evaluateGridState(demandKw: number, timestampStr: string): GridEvaluation {
  const date = new Date(timestampStr);
  const hour = date.getHours(); // 0 to 23

  const isPeakHour = hour >= 18 && hour <= 22;
  const isHighDemand = demandKw > 160.0;
  const isOverload = demandKw >= 200.0;

  let mode: GridMode = "MAIN_GRID";
  let reason = "Demand <= 160 kW and outside peak evening window (18:00-22:00)";

  if (isHighDemand || isPeakHour) {
    mode = "RENEWABLE_STORAGE";
    if (isHighDemand && isPeakHour) {
      reason = `Dual Trigger: High Demand (${demandKw.toFixed(1)} kW > 160 kW) & Evening Window (${hour}:00)`;
    } else if (isHighDemand) {
      reason = `Demand Trigger: High Demand (${demandKw.toFixed(1)} kW > 160 kW)`;
    } else {
      reason = `Time Trigger: Peak Evening Window (${hour}:00 between 18:00-22:00)`;
    }
  }

  return {
    hour,
    demandKw: Number(demandKw.toFixed(2)),
    mode,
    isOverload,
    reason,
    isPeakHour,
    isHighDemand,
    statusColor: isOverload ? "rose" : mode === "RENEWABLE_STORAGE" ? "emerald" : "sky",
  };
}

/**
 * Local heuristic fallback predictor — calibrated diurnal + temperature/solar curve.
 * Produces a realistic 24h demand profile when the live QuickML endpoint is unavailable.
 */
export function heuristicDemandModel(point: TelemetryPoint): number {
  const date = new Date(point.timestamp);
  const hour = date.getHours();

  // Base diurnal load curve (kW) - morning ramp, midday plateau, evening peak
  const diurnalBase =
    95 +
    55 * Math.exp(-Math.pow(hour - 8.5, 2) / 10) + // morning ramp
    40 * Math.exp(-Math.pow(hour - 13, 2) / 18) + // midday plateau
    95 * Math.exp(-Math.pow(hour - 20, 2) / 6); // evening peak

  // Temperature driven cooling load (above 24C adds AC draw)
  const tempEffect = Math.max(0, point.ambient_temp_c - 24) * 3.1;

  // Humidity adds marginal HVAC latent load
  const humidityEffect = Math.max(0, point.humidity_pct - 50) * 0.35;

  // Solar irradiance offsets grid draw slightly during generation hours (rooftop PV, net metering)
  const solarOffset = point.solar_irradiance_wm2 > 0 ? point.solar_irradiance_wm2 * 0.028 : 0;

  const noise = Math.sin(hour * 12.9) * 2.4;

  const demand = diurnalBase + tempEffect + humidityEffect - solarOffset + noise;
  return Math.max(40, Number(demand.toFixed(1)));
}

export function buildForecast(telemetry: TelemetryPoint[]): ForecastPoint[] {
  let soc = 68; // starting battery state of charge %
  const sorted = [...telemetry].sort(
    (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
  );

  return sorted.map((t) => {
    const demandKw = heuristicDemandModel(t);
    const evalResult = evaluateGridState(demandKw, t.timestamp);

    let batteryFlowKw = 0;
    if (evalResult.mode === "RENEWABLE_STORAGE") {
      // discharging to shave peak load, proportional to excess over 140kW baseline
      batteryFlowKw = -Math.min(60, Math.max(12, (demandKw - 140) * 0.55));
      soc = Math.max(8, soc + batteryFlowKw * 0.18);
    } else if (t.solar_irradiance_wm2 > 300) {
      // charging via solar surplus
      batteryFlowKw = Math.min(45, t.solar_irradiance_wm2 * 0.045);
      soc = Math.min(99, soc + batteryFlowKw * 0.12);
    } else {
      batteryFlowKw = -2.5; // trickle self-discharge
      soc = Math.max(8, soc + batteryFlowKw * 0.05);
    }

    const date = new Date(t.timestamp);
    const hourLabel = `${String(date.getHours()).padStart(2, "0")}:00`;

    return {
      ...t,
      hour: evalResult.hour,
      hourLabel,
      demandKw: evalResult.demandKw,
      mode: evalResult.mode,
      reason: evalResult.reason,
      isOverload: evalResult.isOverload,
      isPeakHour: evalResult.isPeakHour,
      isHighDemand: evalResult.isHighDemand,
      statusColor: evalResult.statusColor,
      batterySoc: Number(soc.toFixed(1)),
      batteryFlowKw: Number(batteryFlowKw.toFixed(1)),
    };
  });
}

export const SWITCHING_THRESHOLD_KW = 160;
export const CRITICAL_THRESHOLD_KW = 200;
