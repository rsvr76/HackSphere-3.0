import type { TelemetryPoint } from "./microgridLogic";

/**
 * Generates a realistic 24-hour sample telemetry dataset starting at 00:00 today.
 * Mirrors the sample_test_input.csv schema: timestamp, ambient_temp_c, humidity_pct, solar_irradiance_wm2
 */
export function generateSampleTelemetry(seedDate: Date = new Date()): TelemetryPoint[] {
  const base = new Date(seedDate);
  base.setMinutes(0, 0, 0);
  base.setHours(0);

  const points: TelemetryPoint[] = [];

  for (let h = 0; h < 24; h++) {
    const ts = new Date(base);
    ts.setHours(h);

    // temperature: cool overnight, peaks mid-afternoon
    const temp = 21 + 9 * Math.exp(-Math.pow(h - 15, 2) / 30) - 3 * Math.exp(-Math.pow(h - 4, 2) / 10);
    // humidity: inverse of temperature roughly
    const humidity = 70 - 25 * Math.exp(-Math.pow(h - 15, 2) / 40) + 5 * Math.sin(h);
    // solar irradiance: zero at night, peak at noon
    const solar = h >= 6 && h <= 18 ? Math.max(0, 920 * Math.sin(((h - 6) / 12) * Math.PI)) : 0;

    points.push({
      timestamp: ts.toISOString(),
      ambient_temp_c: Number(temp.toFixed(1)),
      humidity_pct: Number(Math.min(95, Math.max(25, humidity)).toFixed(1)),
      solar_irradiance_wm2: Number(solar.toFixed(0)),
    });
  }

  // Inject an evening heatwave spike to guarantee an overload scenario for demo purposes
  points[20].ambient_temp_c = 38.5;
  points[20].humidity_pct = 61;
  points[19].ambient_temp_c = 36.2;

  return points;
}

export const SAMPLE_CSV_HEADER = "timestamp,ambient_temp_c,humidity_pct,solar_irradiance_wm2";

export function telemetryToCsv(points: TelemetryPoint[]): string {
  const rows = points.map(
    (p) => `${p.timestamp},${p.ambient_temp_c},${p.humidity_pct},${p.solar_irradiance_wm2}`
  );
  return [SAMPLE_CSV_HEADER, ...rows].join("\n");
}

export function parseTelemetryCsv(text: string): { data: TelemetryPoint[]; errors: string[] } {
  const errors: string[] = [];
  const lines = text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 0);

  if (lines.length === 0) {
    return { data: [], errors: ["File is empty."] };
  }

  const header = lines[0].split(",").map((h) => h.trim().toLowerCase());
  const required = ["timestamp", "ambient_temp_c", "humidity_pct", "solar_irradiance_wm2"];
  const missing = required.filter((r) => !header.includes(r));

  if (missing.length > 0) {
    return { data: [], errors: [`Missing required column(s): ${missing.join(", ")}`] };
  }

  const idx = {
    timestamp: header.indexOf("timestamp"),
    temp: header.indexOf("ambient_temp_c"),
    humidity: header.indexOf("humidity_pct"),
    solar: header.indexOf("solar_irradiance_wm2"),
  };

  const data: TelemetryPoint[] = [];

  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split(",");
    if (cols.length < required.length) {
      errors.push(`Row ${i + 1}: expected ${required.length} columns, found ${cols.length}.`);
      continue;
    }
    const ts = cols[idx.timestamp]?.trim();
    const temp = Number(cols[idx.temp]);
    const humidity = Number(cols[idx.humidity]);
    const solar = Number(cols[idx.solar]);

    if (!ts || isNaN(new Date(ts).getTime())) {
      errors.push(`Row ${i + 1}: invalid timestamp "${ts}".`);
      continue;
    }
    if (isNaN(temp) || isNaN(humidity) || isNaN(solar)) {
      errors.push(`Row ${i + 1}: non-numeric telemetry value(s).`);
      continue;
    }

    data.push({
      timestamp: new Date(ts).toISOString(),
      ambient_temp_c: temp,
      humidity_pct: humidity,
      solar_irradiance_wm2: solar,
    });
  }

  if (data.length === 0 && errors.length === 0) {
    errors.push("No valid data rows found.");
  }

  return { data, errors };
}
