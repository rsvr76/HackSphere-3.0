import { useEffect, useMemo, useState } from "react";
import Navbar from "./components/Navbar";
import OverloadBanner from "./components/OverloadBanner";
import KpiMetricsGrid from "./components/KpiMetricsGrid";
import ForecastChart from "./components/ForecastChart";
import TransitionPanel from "./components/TransitionPanel";
import WhatIfSimulator from "./components/WhatIfSimulator";
import CsvUploader from "./components/CsvUploader";
import TelemetryTable from "./components/TelemetryTable";
import SettingsModal, { type ApiSettings } from "./components/SettingsModal";
import { buildForecast, type TelemetryPoint } from "./utils/microgridLogic";
import { generateSampleTelemetry } from "./utils/sampleData";
import { CheckCircle2, Info } from "lucide-react";

interface Toast {
  id: number;
  message: string;
  type: "success" | "info";
}

export default function App() {
  const [telemetry, setTelemetry] = useState<TelemetryPoint[]>(() => generateSampleTelemetry());
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [apiSettings, setApiSettings] = useState<ApiSettings>({
    endpoint: "",
    apiKey: "",
    mockMode: true,
  });
  const [toasts, setToasts] = useState<Toast[]>([]);

  const forecast = useMemo(() => buildForecast(telemetry), [telemetry]);
  const apiConnected = !apiSettings.mockMode && apiSettings.endpoint.length > 0;

  const pushToast = (message: string, type: Toast["type"] = "info") => {
    const id = Date.now();
    setToasts((t) => [...t, { id, message, type }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 4000);
  };

  const handleLoadSample = () => {
    setTelemetry(generateSampleTelemetry());
    pushToast("Sample 24-hour telemetry loaded successfully.", "success");
  };

  const handleCsvData = (data: TelemetryPoint[]) => {
    setTelemetry(data);
    pushToast(`Ingested ${data.length} telemetry rows from CSV upload.`, "success");
  };

  useEffect(() => {
    document.title = "HackSphere 3.0 — Smart Microgrid Controller";
  }, []);

  const current = forecast[0];

  return (
    <div className="min-h-screen bg-[#090d16] text-slate-200 antialiased">
      <Navbar
        apiConnected={apiConnected}
        onOpenSettings={() => setSettingsOpen(true)}
        onLoadSample={handleLoadSample}
      />

      <main className="mx-auto max-w-7xl space-y-6 p-4 md:p-6 lg:p-8">
        {/* Row 1: Alert Banner */}
        <OverloadBanner forecast={forecast} />

        {/* Row 2: KPI Scorecards */}
        <KpiMetricsGrid forecast={forecast} />

        {/* Row 3: Primary Visualizer Bento */}
        <section className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <div className="lg:col-span-8">
            <ForecastChart forecast={forecast} />
          </div>
          <div className="space-y-6 lg:col-span-4">
            {current && <TransitionPanel current={current} />}
            <WhatIfSimulator />
          </div>
        </section>

        {/* Row 4: Telemetry Ingestion & Data Table */}
        <section className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <CsvUploader onDataLoaded={handleCsvData} />
          </div>
          <div className="lg:col-span-8">
            <TelemetryTable forecast={forecast} />
          </div>
        </section>

        <footer className="pb-4 pt-2 text-center text-[11px] text-slate-600">
          HackSphere 3.0 — Smart Energy Microgrid &amp; Demand Forecasting Engine · Deployed via Zoho
          Catalyst Slate · {apiSettings.mockMode ? "Local Heuristic Fallback Engine Active" : "Live QuickML Endpoint"}
        </footer>
      </main>

      <SettingsModal
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        settings={apiSettings}
        onSave={(s) => {
          setApiSettings(s);
          pushToast("API settings saved.", "success");
        }}
      />

      {/* Toast notifications */}
      <div className="pointer-events-none fixed bottom-4 right-4 z-50 flex flex-col gap-2">
        {toasts.map((t) => (
          <div
            key={t.id}
            role="status"
            className={`pointer-events-auto flex items-center gap-2 rounded-lg border px-3.5 py-2.5 text-sm shadow-xl backdrop-blur ${
              t.type === "success"
                ? "border-emerald-500/30 bg-emerald-950/90 text-emerald-200"
                : "border-sky-500/30 bg-sky-950/90 text-sky-200"
            }`}
          >
            {t.type === "success" ? (
              <CheckCircle2 className="h-4 w-4 shrink-0" />
            ) : (
              <Info className="h-4 w-4 shrink-0" />
            )}
            {t.message}
          </div>
        ))}
      </div>
    </div>
  );
}
