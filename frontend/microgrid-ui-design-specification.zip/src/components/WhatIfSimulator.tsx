import { useMemo, useState } from "react";
import { FlaskConical, Zap } from "lucide-react";
import { evaluateGridState, heuristicDemandModel } from "../utils/microgridLogic";
import StatusPill from "./StatusPill";

export default function WhatIfSimulator() {
  const [hour, setHour] = useState(20);
  const [temp, setTemp] = useState(32);
  const [humidity, setHumidity] = useState(55);
  const [solar, setSolar] = useState(100);

  const result = useMemo(() => {
    const ts = new Date();
    ts.setHours(hour, 0, 0, 0);
    const demand = heuristicDemandModel({
      timestamp: ts.toISOString(),
      ambient_temp_c: temp,
      humidity_pct: humidity,
      solar_irradiance_wm2: solar,
    });
    return evaluateGridState(demand, ts.toISOString());
  }, [hour, temp, humidity, solar]);

  return (
    <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4 md:p-5">
      <div className="mb-4 flex items-center gap-2">
        <FlaskConical className="h-4 w-4 text-slate-400" />
        <h2 className="text-sm font-semibold text-slate-100">"What-If" Telemetry Simulator</h2>
      </div>

      <div className="space-y-4">
        <SliderField label="Hour of Day" value={hour} min={0} max={23} step={1} unit=":00" onChange={setHour} />
        <SliderField label="Ambient Temperature" value={temp} min={5} max={45} step={0.5} unit="°C" onChange={setTemp} />
        <SliderField label="Relative Humidity" value={humidity} min={10} max={100} step={1} unit="%" onChange={setHumidity} />
        <SliderField label="Solar Irradiance" value={solar} min={0} max={1000} step={10} unit=" W/m²" onChange={setSolar} />
      </div>

      <div className="mt-5 rounded-lg border border-slate-800 bg-slate-950/50 p-3.5">
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-1.5 text-xs font-medium text-slate-400">
            <Zap className="h-3.5 w-3.5" /> Simulated Demand
          </span>
          <StatusPill color={result.statusColor} pulse>
            {result.isOverload ? "OVERLOAD" : result.mode === "RENEWABLE_STORAGE" ? "RENEWABLE" : "MAIN GRID"}
          </StatusPill>
        </div>
        <p
          className={`mt-1.5 text-2xl font-bold tabular-nums ${
            result.isOverload ? "text-rose-400" : "text-slate-50"
          }`}
        >
          {result.demandKw.toFixed(1)} <span className="text-sm font-medium text-slate-500">kW</span>
        </p>
        <p className="mt-1.5 text-[11px] leading-relaxed text-slate-500">{result.reason}</p>
      </div>
    </div>
  );
}

function SliderField({
  label,
  value,
  min,
  max,
  step,
  unit,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  unit: string;
  onChange: (v: number) => void;
}) {
  return (
    <div>
      <div className="mb-1.5 flex items-center justify-between">
        <label className="text-xs font-medium text-slate-400">{label}</label>
        <span className="text-xs font-semibold tabular-nums text-slate-200">
          {value}
          {unit}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="h-1.5 w-full cursor-pointer appearance-none rounded-full bg-slate-800 accent-emerald-500"
        aria-label={label}
      />
    </div>
  );
}
