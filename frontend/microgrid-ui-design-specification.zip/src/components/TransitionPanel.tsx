import { BatteryFull, Leaf, PlugZap, Radar } from "lucide-react";
import type { ForecastPoint } from "../utils/microgridLogic";
import StatusPill from "./StatusPill";

export default function TransitionPanel({ current }: { current: ForecastPoint }) {
  const isRenewable = current.mode === "RENEWABLE_STORAGE";

  return (
    <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4 md:p-5">
      <div className="mb-4 flex items-center gap-2">
        <Radar className="h-4 w-4 text-slate-400" />
        <h2 className="text-sm font-semibold text-slate-100">Smart Transition Controller</h2>
      </div>

      {/* Hero mode badge */}
      <div
        className={`relative overflow-hidden rounded-xl border p-4 ${
          isRenewable
            ? "border-emerald-500/30 bg-emerald-500/5"
            : "border-sky-500/30 bg-sky-500/5"
        }`}
      >
        <div className="flex items-center gap-3">
          <div
            className={`relative flex h-11 w-11 shrink-0 items-center justify-center rounded-full ${
              isRenewable ? "bg-emerald-500/15" : "bg-sky-500/15"
            }`}
          >
            <span
              className={`absolute inline-flex h-full w-full animate-ping rounded-full opacity-40 ${
                isRenewable ? "bg-emerald-400" : "bg-sky-400"
              }`}
            />
            {isRenewable ? (
              <Leaf className="relative h-5 w-5 text-emerald-400" />
            ) : (
              <PlugZap className="relative h-5 w-5 text-sky-400" />
            )}
          </div>
          <div>
            <p className={`text-sm font-bold ${isRenewable ? "text-emerald-300" : "text-sky-300"}`}>
              {isRenewable ? "Renewable Storage Mode" : "Main Grid Mode"}
            </p>
            <p className="text-xs text-slate-400">
              {isRenewable
                ? "Source: Renewable Battery Storage (Peak load shaving active)"
                : "Source: Main Utility Grid (Base load operating within safe limits)"}
            </p>
          </div>
        </div>
        <p className="mt-3 rounded-lg bg-black/20 px-3 py-2 text-xs leading-relaxed text-slate-300">
          <span className="font-semibold text-slate-200">Triggered by:</span> {current.reason}
        </p>
      </div>

      {/* Decision matrix */}
      <div className="mt-4 space-y-2">
        <p className="text-[11px] font-semibold uppercase tracking-wide text-slate-500">
          Live Decision Matrix
        </p>
        <div className="flex items-center justify-between rounded-lg border border-slate-800 bg-slate-950/40 px-3 py-2 text-xs">
          <span className="text-slate-400">Demand &gt; 160 kW</span>
          <StatusPill color={current.isHighDemand ? "rose" : "sky"}>
            {current.isHighDemand ? "TRUE" : "FALSE"}
          </StatusPill>
        </div>
        <div className="flex items-center justify-between rounded-lg border border-slate-800 bg-slate-950/40 px-3 py-2 text-xs">
          <span className="text-slate-400">Hour in 18:00–22:00</span>
          <StatusPill color={current.isPeakHour ? "rose" : "sky"}>
            {current.isPeakHour ? "TRUE" : "FALSE"}
          </StatusPill>
        </div>
        <div className="flex items-center justify-between rounded-lg border border-slate-800 bg-slate-950/40 px-3 py-2 text-xs">
          <span className="text-slate-400">Demand ≥ 200 kW (Overload)</span>
          <StatusPill color={current.isOverload ? "rose" : "sky"}>
            {current.isOverload ? "TRUE" : "FALSE"}
          </StatusPill>
        </div>
        <div className="flex items-center justify-between rounded-lg border border-emerald-500/20 bg-emerald-500/5 px-3 py-2 text-xs">
          <span className="flex items-center gap-1.5 font-medium text-slate-300">
            <BatteryFull className="h-3.5 w-3.5" /> Dispatch Signal
          </span>
          <StatusPill color={current.statusColor} pulse>
            {isRenewable ? "RENEWABLE" : "MAIN GRID"}
          </StatusPill>
        </div>
      </div>
    </div>
  );
}
