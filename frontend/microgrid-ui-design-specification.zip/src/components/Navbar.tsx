import { Activity, Settings, UploadCloud, Zap } from "lucide-react";

export default function Navbar({
  apiConnected,
  onOpenSettings,
  onLoadSample,
}: {
  apiConnected: boolean;
  onOpenSettings: () => void;
  onLoadSample: () => void;
}) {
  return (
    <header className="sticky top-0 z-40 border-b border-slate-800/80 bg-[#090d16]/90 backdrop-blur-md">
      <div className="mx-auto flex h-14 max-w-7xl items-center justify-between gap-4 px-4 md:px-6 lg:px-8">
        <div className="flex items-center gap-2.5">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-emerald-500 to-sky-600 shadow-lg shadow-emerald-500/20">
            <Zap className="h-4.5 w-4.5 text-white" strokeWidth={2.5} />
          </div>
          <div className="leading-tight">
            <h1 className="text-sm font-semibold tracking-tight text-slate-50">
              HackSphere 3.0
            </h1>
            <p className="text-[11px] text-slate-500">Smart Microgrid Controller</p>
          </div>
        </div>

        <div className="flex items-center gap-2 md:gap-3">
          <div
            className="hidden items-center gap-1.5 rounded-full border border-slate-800 bg-slate-900/60 px-3 py-1.5 text-xs font-medium text-slate-300 sm:flex"
            aria-label="QuickML API connection status"
          >
            <span className="relative flex h-2 w-2">
              <span
                className={`absolute inline-flex h-full w-full animate-ping rounded-full opacity-75 ${
                  apiConnected ? "bg-emerald-400" : "bg-amber-400"
                }`}
              />
              <span
                className={`relative inline-flex h-2 w-2 rounded-full ${
                  apiConnected ? "bg-emerald-400" : "bg-amber-400"
                }`}
              />
            </span>
            <Activity className="h-3.5 w-3.5 text-slate-500" />
            {apiConnected ? "QuickML Connected" : "Offline Fallback Active"}
          </div>

          <button
            onClick={onLoadSample}
            className="inline-flex items-center gap-1.5 rounded-lg border border-slate-800 bg-slate-900/60 px-3 py-1.5 text-xs font-medium text-slate-300 transition-colors hover:border-slate-700 hover:bg-slate-800/60 hover:text-slate-100"
          >
            <UploadCloud className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">Load Sample Data</span>
            <span className="sm:hidden">Sample</span>
          </button>

          <button
            onClick={onOpenSettings}
            aria-label="Open API settings"
            className="inline-flex h-8 w-8 items-center justify-center rounded-lg border border-slate-800 bg-slate-900/60 text-slate-400 transition-colors hover:border-slate-700 hover:bg-slate-800/60 hover:text-slate-100"
          >
            <Settings className="h-4 w-4" />
          </button>
        </div>
      </div>
    </header>
  );
}
