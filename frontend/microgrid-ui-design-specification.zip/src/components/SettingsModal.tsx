import { useState } from "react";
import { KeyRound, Link2, Save, Settings2, X } from "lucide-react";

export interface ApiSettings {
  endpoint: string;
  apiKey: string;
  mockMode: boolean;
}

export default function SettingsModal({
  open,
  onClose,
  settings,
  onSave,
}: {
  open: boolean;
  onClose: () => void;
  settings: ApiSettings;
  onSave: (s: ApiSettings) => void;
}) {
  const [local, setLocal] = useState(settings);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="settings-title"
    >
      <div className="w-full max-w-md rounded-xl border border-slate-800 bg-slate-900 p-5 shadow-2xl">
        <div className="mb-4 flex items-center justify-between">
          <h2 id="settings-title" className="flex items-center gap-2 text-sm font-semibold text-slate-100">
            <Settings2 className="h-4 w-4 text-slate-400" /> QuickML API Settings
          </h2>
          <button
            onClick={onClose}
            aria-label="Close settings"
            className="inline-flex h-7 w-7 items-center justify-center rounded-md text-slate-400 hover:bg-slate-800 hover:text-slate-100"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="mb-1.5 flex items-center gap-1.5 text-xs font-medium text-slate-400">
              <Link2 className="h-3.5 w-3.5" /> Catalyst QuickML Endpoint URL
            </label>
            <input
              type="text"
              value={local.endpoint}
              onChange={(e) => setLocal((s) => ({ ...s, endpoint: e.target.value }))}
              placeholder="https://your-project.api.catalyst.zoho.com/quickml/predict"
              className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-slate-100 placeholder:text-slate-600 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
            />
          </div>

          <div>
            <label className="mb-1.5 flex items-center gap-1.5 text-xs font-medium text-slate-400">
              <KeyRound className="h-3.5 w-3.5" /> API Key / Auth Token
            </label>
            <input
              type="password"
              value={local.apiKey}
              onChange={(e) => setLocal((s) => ({ ...s, apiKey: e.target.value }))}
              placeholder="••••••••••••••••"
              className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-sm text-slate-100 placeholder:text-slate-600 focus:border-sky-500 focus:outline-none focus:ring-1 focus:ring-sky-500"
            />
          </div>

          <label className="flex items-center justify-between rounded-lg border border-slate-800 bg-slate-950/50 px-3 py-2.5">
            <div>
              <p className="text-xs font-medium text-slate-200">Force Offline Fallback</p>
              <p className="text-[11px] text-slate-500">Use local heuristic model instead of live API</p>
            </div>
            <input
              type="checkbox"
              checked={local.mockMode}
              onChange={(e) => setLocal((s) => ({ ...s, mockMode: e.target.checked }))}
              className="h-4 w-4 accent-emerald-500"
            />
          </label>
        </div>

        <div className="mt-5 flex justify-end gap-2">
          <button
            onClick={onClose}
            className="rounded-lg border border-slate-700 px-3.5 py-2 text-xs font-medium text-slate-300 hover:bg-slate-800"
          >
            Cancel
          </button>
          <button
            onClick={() => {
              onSave(local);
              onClose();
            }}
            className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3.5 py-2 text-xs font-semibold text-white hover:bg-emerald-500"
          >
            <Save className="h-3.5 w-3.5" /> Save Settings
          </button>
        </div>
      </div>
    </div>
  );
}
