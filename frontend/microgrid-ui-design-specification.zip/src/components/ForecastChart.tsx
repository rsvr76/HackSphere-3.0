import { useMemo, useState } from "react";
import {
  Area,
  ComposedChart,
  Line,
  ReferenceArea,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  CartesianGrid,
} from "recharts";
import { Droplets, Sun, Thermometer, Zap } from "lucide-react";
import type { ForecastPoint } from "../utils/microgridLogic";
import { CRITICAL_THRESHOLD_KW, SWITCHING_THRESHOLD_KW } from "../utils/microgridLogic";

function CustomTooltip({ active, payload }: any) {
  if (!active || !payload || !payload.length) return null;
  const d: ForecastPoint = payload[0].payload;

  const modeLabel = d.mode === "RENEWABLE_STORAGE" ? "Renewable Storage Mode" : "Main Grid Mode";
  const modeColor = d.isOverload ? "text-rose-400" : d.mode === "RENEWABLE_STORAGE" ? "text-emerald-400" : "text-sky-400";

  return (
    <div className="min-w-[230px] rounded-lg border border-slate-700 bg-slate-900/95 p-3 shadow-xl backdrop-blur">
      <div className="mb-2 flex items-center justify-between border-b border-slate-800 pb-2">
        <span className="text-xs font-semibold text-slate-300">{d.hourLabel}</span>
        <span className={`text-xs font-bold ${modeColor}`}>{modeLabel}</span>
      </div>
      <div className="space-y-1.5 text-xs">
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-1.5 text-slate-400">
            <Zap className="h-3 w-3" /> Demand
          </span>
          <span className={`font-semibold tabular-nums ${d.isOverload ? "text-rose-400" : "text-slate-100"}`}>
            {d.demandKw.toFixed(1)} kW
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-1.5 text-slate-400">
            <Thermometer className="h-3 w-3" /> Temperature
          </span>
          <span className="font-medium tabular-nums text-slate-200">{d.ambient_temp_c.toFixed(1)}°C</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-1.5 text-slate-400">
            <Droplets className="h-3 w-3" /> Humidity
          </span>
          <span className="font-medium tabular-nums text-slate-200">{d.humidity_pct.toFixed(0)}%</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-1.5 text-slate-400">
            <Sun className="h-3 w-3" /> Solar Irradiance
          </span>
          <span className="font-medium tabular-nums text-slate-200">{d.solar_irradiance_wm2.toFixed(0)} W/m²</span>
        </div>
      </div>
      <div className="mt-2 border-t border-slate-800 pt-2 text-[11px] leading-snug text-slate-400">
        {d.reason}
      </div>
    </div>
  );
}

export default function ForecastChart({ forecast }: { forecast: ForecastPoint[] }) {
  const [showTemp, setShowTemp] = useState(false);
  const [showSolar, setShowSolar] = useState(false);

  const areaColor = useMemo(() => {
    const hasOverload = forecast.some((f) => f.isOverload);
    return hasOverload ? "#ef4444" : "#10b981";
  }, [forecast]);

  const maxDemand = Math.max(...forecast.map((f) => f.demandKw), CRITICAL_THRESHOLD_KW + 20);

  return (
    <div className="flex h-full flex-col rounded-xl border border-slate-800 bg-slate-900/50 p-4 md:p-5">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-sm font-semibold text-slate-100">24-Hour Demand Forecast</h2>
          <p className="mt-0.5 text-xs text-slate-500">
            Hourly load prediction with switching &amp; critical thresholds
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowTemp((v) => !v)}
            className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-medium transition-colors ${
              showTemp
                ? "border-orange-500/40 bg-orange-500/10 text-orange-300"
                : "border-slate-800 bg-slate-900 text-slate-500 hover:text-slate-300"
            }`}
          >
            <Thermometer className="h-3 w-3" /> Temp
          </button>
          <button
            onClick={() => setShowSolar((v) => !v)}
            className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-medium transition-colors ${
              showSolar
                ? "border-amber-500/40 bg-amber-500/10 text-amber-300"
                : "border-slate-800 bg-slate-900 text-slate-500 hover:text-slate-300"
            }`}
          >
            <Sun className="h-3 w-3" /> Solar
          </button>
        </div>
      </div>

      <div className="h-[340px] w-full flex-1 md:h-[400px]">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={forecast} margin={{ top: 10, right: 12, left: -16, bottom: 0 }}>
            <defs>
              <linearGradient id="demandFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={areaColor} stopOpacity={0.45} />
                <stop offset="100%" stopColor={areaColor} stopOpacity={0.02} />
              </linearGradient>
            </defs>

            <CartesianGrid stroke="#1e293b" strokeDasharray="3 6" vertical={false} />

            {/* Shaded evening peak window 18:00-22:00 */}
            <ReferenceArea x1="18:00" x2="22:00" fill="#f59e0b" fillOpacity={0.06} strokeOpacity={0} />

            <XAxis
              dataKey="hourLabel"
              tick={{ fill: "#64748b", fontSize: 11 }}
              axisLine={{ stroke: "#1e293b" }}
              tickLine={false}
              interval={2}
            />
            <YAxis
              yAxisId="demand"
              domain={[0, Math.ceil(maxDemand / 20) * 20]}
              tick={{ fill: "#64748b", fontSize: 11 }}
              axisLine={false}
              tickLine={false}
              width={44}
              label={{ value: "kW", angle: -90, position: "insideLeft", fill: "#475569", fontSize: 11 }}
            />
            {(showTemp || showSolar) && (
              <YAxis
                yAxisId="weather"
                orientation="right"
                tick={{ fill: "#64748b", fontSize: 11 }}
                axisLine={false}
                tickLine={false}
                width={36}
              />
            )}

            <Tooltip content={<CustomTooltip />} cursor={{ stroke: "#475569", strokeDasharray: "3 3" }} />

            <ReferenceLine
              yAxisId="demand"
              y={SWITCHING_THRESHOLD_KW}
              stroke="#f59e0b"
              strokeDasharray="5 4"
              strokeWidth={1.5}
              label={{
                value: `Switching 160kW`,
                position: "insideTopLeft",
                fill: "#f59e0b",
                fontSize: 10,
              }}
            />
            <ReferenceLine
              yAxisId="demand"
              y={CRITICAL_THRESHOLD_KW}
              stroke="#ef4444"
              strokeWidth={1.5}
              label={{
                value: `Critical 200kW`,
                position: "insideTopLeft",
                fill: "#ef4444",
                fontSize: 10,
              }}
            />

            <Area
              yAxisId="demand"
              type="monotone"
              dataKey="demandKw"
              stroke={areaColor}
              strokeWidth={2.5}
              fill="url(#demandFill)"
              dot={(props: any) => {
                const { cx, cy, payload, index } = props;
                if (!payload.isOverload) return <circle key={`dot-${index}`} cx={cx} cy={cy} r={0} />;
                return (
                  <circle
                    key={`dot-${index}`}
                    cx={cx}
                    cy={cy}
                    r={4}
                    fill="#ef4444"
                    stroke="#fff"
                    strokeWidth={1.5}
                  />
                );
              }}
              activeDot={{ r: 5, strokeWidth: 2, stroke: "#fff" }}
            />

            {showTemp && (
              <Line
                yAxisId="weather"
                type="monotone"
                dataKey="ambient_temp_c"
                stroke="#fb923c"
                strokeWidth={1.5}
                dot={false}
                strokeDasharray="2 2"
              />
            )}
            {showSolar && (
              <Line
                yAxisId="weather"
                type="monotone"
                dataKey="solar_irradiance_wm2"
                stroke="#fbbf24"
                strokeWidth={1.5}
                dot={false}
                strokeDasharray="2 2"
              />
            )}
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[11px] text-slate-500">
        <span className="flex items-center gap-1.5">
          <span className="h-0.5 w-3 rounded-full bg-amber-500" /> Switching Threshold (160 kW)
        </span>
        <span className="flex items-center gap-1.5">
          <span className="h-0.5 w-3 rounded-full bg-rose-500" /> Critical Threshold (200 kW)
        </span>
        <span className="flex items-center gap-1.5">
          <span className="h-2 w-2 rounded-full bg-amber-500/20" /> Evening Peak Window (18:00–22:00)
        </span>
        <span className="flex items-center gap-1.5">
          <span className="h-2 w-2 rounded-full border-2 border-white bg-rose-500" /> Overload Hour
        </span>
      </div>
    </div>
  );
}
