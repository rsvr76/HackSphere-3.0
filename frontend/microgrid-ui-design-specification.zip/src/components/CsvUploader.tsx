import { useCallback, useRef, useState } from "react";
import { AlertCircle, CheckCircle2, Download, FileSpreadsheet, UploadCloud } from "lucide-react";
import type { TelemetryPoint } from "../utils/microgridLogic";
import { parseTelemetryCsv, telemetryToCsv, generateSampleTelemetry } from "../utils/sampleData";

export default function CsvUploader({
  onDataLoaded,
}: {
  onDataLoaded: (data: TelemetryPoint[]) => void;
}) {
  const [dragging, setDragging] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);
  const [errors, setErrors] = useState<string[]>([]);
  const [success, setSuccess] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  const processFile = useCallback(
    (file: File) => {
      setErrors([]);
      setSuccess(null);
      setFileName(file.name);

      if (!file.name.toLowerCase().endsWith(".csv")) {
        setErrors(["Invalid file type. Only .csv files are accepted."]);
        return;
      }

      setProgress(20);
      const reader = new FileReader();
      reader.onprogress = (e) => {
        if (e.lengthComputable) setProgress(20 + Math.round((e.loaded / e.total) * 60));
      };
      reader.onload = () => {
        setProgress(90);
        const text = String(reader.result ?? "");
        const { data, errors: parseErrors } = parseTelemetryCsv(text);
        setProgress(100);

        if (parseErrors.length > 0) {
          setErrors(parseErrors.slice(0, 6));
        }
        if (data.length > 0) {
          onDataLoaded(data);
          setSuccess(`Loaded ${data.length} hourly telemetry rows — schema verified.`);
        }
        setTimeout(() => setProgress(0), 800);
      };
      reader.onerror = () => {
        setErrors(["Failed to read file."]);
        setProgress(0);
      };
      reader.readAsText(file);
    },
    [onDataLoaded]
  );

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) processFile(file);
  };

  const downloadSample = () => {
    const sample = generateSampleTelemetry();
    const csv = telemetryToCsv(sample);
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "sample_test_input.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4 md:p-5">
      <div className="mb-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <FileSpreadsheet className="h-4 w-4 text-slate-400" />
          <h2 className="text-sm font-semibold text-slate-100">Telemetry Ingestion</h2>
        </div>
        <button
          onClick={downloadSample}
          className="inline-flex items-center gap-1.5 text-xs font-medium text-sky-400 hover:text-sky-300"
        >
          <Download className="h-3.5 w-3.5" /> Download Sample CSV
        </button>
      </div>

      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={handleDrop}
        onClick={() => inputRef.current?.click()}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => e.key === "Enter" && inputRef.current?.click()}
        aria-label="CSV upload drop zone"
        className={`flex cursor-pointer flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed px-4 py-8 text-center transition-colors ${
          dragging
            ? "border-emerald-500 bg-emerald-500/5"
            : "border-slate-700 bg-slate-950/30 hover:border-slate-600"
        }`}
      >
        <UploadCloud className={`h-7 w-7 ${dragging ? "text-emerald-400" : "text-slate-500"}`} />
        <p className="text-sm font-medium text-slate-300">
          Drag &amp; drop CSV, or <span className="text-emerald-400">browse</span>
        </p>
        <p className="text-[11px] text-slate-500">
          Schema: timestamp, ambient_temp_c, humidity_pct, solar_irradiance_wm2
        </p>
        <input
          ref={inputRef}
          type="file"
          accept=".csv"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) processFile(file);
          }}
        />
      </div>

      {progress > 0 && (
        <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-slate-800">
          <div
            className="h-full rounded-full bg-emerald-500 transition-all duration-200"
            style={{ width: `${progress}%` }}
          />
        </div>
      )}

      {fileName && errors.length === 0 && success && (
        <div className="mt-3 flex items-start gap-2 rounded-lg border border-emerald-500/30 bg-emerald-500/5 px-3 py-2 text-xs text-emerald-300">
          <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0" />
          <span>{success}</span>
        </div>
      )}

      {errors.length > 0 && (
        <div className="mt-3 space-y-1 rounded-lg border border-rose-500/30 bg-rose-500/5 px-3 py-2 text-xs text-rose-300">
          {errors.map((err, i) => (
            <div key={i} className="flex items-start gap-2">
              <AlertCircle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
              <span>{err}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
