import { useMemo, useState } from "react";
import { ArrowDown, ArrowUp, Download, ListTree, TriangleAlert } from "lucide-react";
import type { ForecastPoint } from "../utils/microgridLogic";
import StatusPill from "./StatusPill";

type SortKey = "hourLabel" | "demandKw" | "ambient_temp_c" | "humidity_pct" | "solar_irradiance_wm2";

export default function TelemetryTable({ forecast }: { forecast: ForecastPoint[] }) {
  const [sortKey, setSortKey] = useState<SortKey>("hourLabel");
  const [sortAsc, setSortAsc] = useState(true);

  const sorted = useMemo(() => {
    const copy = [...forecast];
    copy.sort((a, b) => {
      const av = a[sortKey];
      const bv = b[sortKey];
      const cmp = typeof av === "string" ? av.localeCompare(bv as string) : (av as number) - (bv as number);
      return sortAsc ? cmp : -cmp;
    });
    return copy;
  }, [forecast, sortKey, sortAsc]);

  const toggleSort = (key: SortKey) => {
    if (key === sortKey) setSortAsc((a) => !a);
    else {
      setSortKey(key);
      setSortAsc(true);
    }
  };

  const downloadPredictions = () => {
    const rows = forecast.map((f) => `${f.timestamp},${f.demandKw.toFixed(2)}`);
    const csv = ["timestamp,target_demand_kw", ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "predictions.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  const Header = ({ label, keyName }: { label: string; keyName: SortKey }) => (
    <th
      onClick={() => toggleSort(keyName)}
      className="cursor-pointer select-none whitespace-nowrap px-3 py-2.5 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500 hover:text-slate-300"
    >
      <span className="inline-flex items-center gap-1">
        {label}
        {sortKey === keyName &&
          (sortAsc ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />)}
      </span>
    </th>
  );

  return (
    <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4 md:p-5">
      <div className="mb-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <ListTree className="h-4 w-4 text-slate-400" />
          <h2 className="text-sm font-semibold text-slate-100">24-Hour Forecast Schedule</h2>
        </div>
        <button
          onClick={downloadPredictions}
          className="inline-flex items-center gap-1.5 rounded-lg border border-slate-800 bg-slate-950/50 px-2.5 py-1.5 text-xs font-medium text-slate-300 hover:border-slate-700 hover:text-slate-100"
        >
          <Download className="h-3.5 w-3.5" /> Download Predictions CSV
        </button>
      </div>

      <div className="max-h-[420px] overflow-auto rounded-lg border border-slate-800">
        <table className="w-full border-collapse text-sm">
          <thead className="sticky top-0 bg-slate-950/95 backdrop-blur">
            <tr>
              <Header label="Hour" keyName="hourLabel" />
              <Header label="Temp °C" keyName="ambient_temp_c" />
              <Header label="Humidity %" keyName="humidity_pct" />
              <Header label="Solar W/m²" keyName="solar_irradiance_wm2" />
              <Header label="Demand kW" keyName="demandKw" />
              <th className="whitespace-nowrap px-3 py-2.5 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                Grid Mode
              </th>
              <th className="whitespace-nowrap px-3 py-2.5 text-left text-[11px] font-semibold uppercase tracking-wide text-slate-500">
                Overload
              </th>
            </tr>
          </thead>
          <tbody>
            {sorted.map((row) => (
              <tr
                key={row.timestamp}
                className={`border-t border-slate-800/80 transition-colors hover:bg-slate-800/30 ${
                  row.isOverload ? "bg-rose-500/5" : ""
                }`}
              >
                <td className="whitespace-nowrap px-3 py-2 font-medium text-slate-200">{row.hourLabel}</td>
                <td className="whitespace-nowrap px-3 py-2 text-slate-400 tabular-nums">
                  {row.ambient_temp_c.toFixed(1)}
                </td>
                <td className="whitespace-nowrap px-3 py-2 text-slate-400 tabular-nums">
                  {row.humidity_pct.toFixed(0)}
                </td>
                <td className="whitespace-nowrap px-3 py-2 text-slate-400 tabular-nums">
                  {row.solar_irradiance_wm2.toFixed(0)}
                </td>
                <td
                  className={`whitespace-nowrap px-3 py-2 font-semibold tabular-nums ${
                    row.isOverload ? "text-rose-400" : "text-slate-200"
                  }`}
                >
                  {row.demandKw.toFixed(1)}
                </td>
                <td className="whitespace-nowrap px-3 py-2">
                  <StatusPill color={row.statusColor}>
                    {row.mode === "RENEWABLE_STORAGE" ? "Renewable" : "Main Grid"}
                  </StatusPill>
                </td>
                <td className="whitespace-nowrap px-3 py-2">
                  {row.isOverload ? (
                    <span className="inline-flex items-center gap-1 text-xs font-semibold text-rose-400">
                      <TriangleAlert className="h-3.5 w-3.5" /> Alert
                    </span>
                  ) : (
                    <span className="text-xs text-slate-600">—</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
